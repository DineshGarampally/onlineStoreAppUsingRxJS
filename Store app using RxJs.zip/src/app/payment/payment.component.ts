import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { generate } from 'rxjs';
import { tap } from 'rxjs/internal/operators/tap';
import { map, toArray } from 'rxjs/operators';
import { ProductsServiceService } from '../service/products-service.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  constructor(private _fb: FormBuilder,private _productService:ProductsServiceService, private _router:Router) { }

  amount: number = 0;
  months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  cardClick = true;
  card = "";
  disable = false;
  expiryErr = false;
  date = new Date;
  presentYear = this.date.getFullYear()
  years: any
  currentMonth = this.date.getMonth();
  image:any;
  private CardNumberValidators = [
    Validators.required,
    Validators.pattern('^[1-9]{1}[0-9]{15}')
  ]
  paymentForm = this._fb.group({
    CardType: ["", Validators.required],
    CardNumber: ["", this.CardNumberValidators],
    CardName: ["", [Validators.required, Validators.pattern("^[A-Za-z]+[a-zA-Z ]{5,}")]],
    CardCvv: ["", [Validators.required, Validators.pattern('^[1-9]{1}[0-9]{2}')]],
    ExpiryDate: this._fb.group({
      expiryMonth: [null, Validators.required],
      expiryYear: [null, Validators.required]
    })
  })

  // For wrong dates entry
  get expiryYear() {
    return this.paymentForm.get('ExpiryDate')?.get('expiryYear')?.value;
  }
  get expiryMonth() {
    return this.paymentForm.get('ExpiryDate')?.get('expiryMonth')?.value;
  }
  checkExp() {
    var currentYear = this.date.getFullYear();
    if (this.expiryYear == currentYear) {
      if ((this.months.indexOf(this.expiryMonth)) < this.currentMonth) {
        this.disable = true;
        this.expiryErr = true;
      } else {
        this.disable = false;
        this.expiryErr = false;
      }
    } else {
      this.disable = false;
      this.expiryErr = false;
    }
  }

  ngOnInit(): void {

    //generate 5 years
    generate(1,x=>x<=5,x=>x+1).pipe(map((x)=>x=this.presentYear++),toArray()).subscribe(x=>this.years=x)
   
    this.paymentForm.get('CardType')?.valueChanges.subscribe(val=>{
      if(val=="Visa"){
        this.card="Visa";
        this.cardClick=false;
        this.paymentForm.controls['CardNumber'].setValidators(this.CardNumberValidators.concat(Validators.pattern('^[4][0-9]{15}$')))
      }else if(val=="MasterCard"){
        this.card="MasterCard";
        this.cardClick=false;
        this.paymentForm.controls['CardNumber'].setValidators(this.CardNumberValidators.concat(Validators.pattern('^[5][0-9]{15}$')))
      }
      this.paymentForm.controls['CardNumber'].updateValueAndValidity();
    })
    var product=this._productService.buyingItem
    this.amount=product.price*product.quantity;
    this.image=product.image;
  }

  onSubmit(){
    this._productService.removeFromCart();
    this._router.navigate(['confirmOrder'])
    
  }

}
