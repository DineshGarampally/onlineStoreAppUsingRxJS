import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { from } from 'rxjs/internal/observable/from';
import { filter } from 'rxjs/internal/operators/filter';
import { toArray } from 'rxjs/internal/operators/toArray';
import { ProductsServiceService } from '../service/products-service.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartItems:Array<any>=[];
  emptyCart=true;
  cartItemsLength:any;
  constructor(private _productService:ProductsServiceService, private _router:Router) { }
  

  deleteItem(itemId:number){
    from(this.cartItems).pipe(filter((data: any) => data.id != itemId), toArray()).subscribe((data: any) => { this.cartItems = data });
    this._productService.numberOfCartItems.next(this.cartItems.length)
    this._productService.updateCart(this.cartItems);
    this.emptyCart=this.cartItems.length<1?true:false;
  }

  buyItem(itemId:number){
    var index=this.findIndexOfItem(itemId);
    this._productService.buyProducts(index);
    this._router.navigate(['payment']);
  }
  quantity(id:number,event:any){
    var index=this.findIndexOfItem(id)
    this.cartItems[index].quantity=parseInt(event.target.value);
    this._productService.updateCart(this.cartItems);
  }

  findIndexOfItem(itemId:any){
    return this.cartItems.findIndex((data)=>data.id==itemId);
  }
  ngOnInit(): void {
    this.cartItems=this._productService.cartItems;
    this.cartItemsLength=this.cartItems.length;
    this.emptyCart=(this.cartItemsLength>0)?false:true;
  }
}
