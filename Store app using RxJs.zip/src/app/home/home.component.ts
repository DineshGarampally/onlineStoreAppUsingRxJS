import { AfterViewInit, Component, OnInit } from '@angular/core';
import { distinct, filter,toArray } from "rxjs/operators";
import { from, Observable } from 'rxjs';
import { ProductsServiceService } from '../service/products-service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  products$: any;
  filters: Array<any> = []
  allItems: Array<any> = [];
  items: Array<any> = [];
  flag = true;
  constructor(private _productService: ProductsServiceService) { }
  ngOnInit(): void {
    const productsFetch$ = new Observable(subscriber => {
      fetch("https://fakestoreapi.com/products")
        .then(res => res.json())
        .then(body => {
          subscriber.next(body);
          subscriber.complete();
        })
        .catch(err => subscriber.error(err))
    })
    this.products$ = productsFetch$;
    this.products$.subscribe((data: any) => {
      this.allItems = data;
      this.items = data;
      from(this.allItems).pipe(distinct((items: any) => items.category), toArray()).subscribe((data: any) => { this.filters = data})
    })
  }

  filter(event: any) {
    var category = event.target.value;
    if (this.flag) {
      this.items = [];
      from(this.allItems).pipe(filter((data: any) => data.category == category), toArray()).subscribe((data: any) => { this.items = data})
      this.flag = false;
    } else {
      if (event.target.checked) {
        from(this.allItems).pipe(filter((data: any) => data.category == category)).subscribe((data: any) => { this.items.push(data)})
      } else {
        from(this.items).pipe(filter((data: any) => data.category != category), toArray()).subscribe((data: any) => { this.items = data})
        if (this.items.length < 1) {
          this.items = this.allItems;
          this.flag = true
        }
      }
    }
  }
  addToCart(productId: number) {
    this._productService.sendCartItems(this.allItems[productId - 1])
  }
  ngAfterViewInit() { }
}
