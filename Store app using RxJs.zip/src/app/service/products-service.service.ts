import { Injectable } from '@angular/core';
import { from, of, Subject } from 'rxjs';
import { filter, toArray } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductsServiceService {

  constructor() { }
  cartItems:Array<any>=[];
  buyingItem:any;
  moveTocart=new Subject();
  numberOfCartItems=new Subject();
  sendCartItems(data: any) {
    data.quantity=1;
    if (this.cartItems.length == 0) this.cartItems.push(data)
    else {
      var index = this.cartItems.findIndex((product: any) => {
        if (product.id == data.id) return product;
      })
      if (index == -1) {
        this.cartItems.push(data);
      }
    }
    if(this.cartItems.length>0) this.numberOfCartItems.next(this.cartItems.length)
  }
  
 
  updateCart(cartItems:any){
    this.cartItems=cartItems;
  }

  buyProducts(index:any){
    this.buyingItem=this.cartItems[index]; 
  }

  removeFromCart() {
    from(this.cartItems).pipe(filter((data)=>{return data.id!=this.buyingItem.id}),toArray())
    .subscribe((products: any) => this.cartItems =products)
    this.numberOfCartItems.next(this.cartItems.length)
  }
  ngOnInit(){

  }

}
