import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CartComponent } from './cart/cart.component';
import { HomeComponent } from './home/home.component';
import { OrderConfirmComponent } from './order-confirm/order-confirm.component';
import { PaymentComponent } from './payment/payment.component';
import { WildCardComponent } from './wild-card/wild-card.component';

const routes: Routes = [
  {path:"home",component:HomeComponent},
  {path:"cart",component:CartComponent},
  {path:"payment",component:PaymentComponent}, 
  {path:"confirmOrder",component:OrderConfirmComponent}, 
  {path:"",pathMatch:"full",redirectTo:"home"},
  {path:"**",component:WildCardComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
